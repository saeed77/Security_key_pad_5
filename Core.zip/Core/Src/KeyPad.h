#include "stm32f1xx_hal.h"
#include <stdbool.h>
#include <stdlib.h>
#include "main.h"

#ifndef _KEYPAD_H_
#define _KEYPAD_H_


char Get_Key(void);

#endif 